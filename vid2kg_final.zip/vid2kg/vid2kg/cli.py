import argparse, pathlib, json, sys
from rich import print as rprint
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from .downloader import fetch_audio
from .transcribe import transcribe
from .translate import translate_transcript
from .fuzzy_matcher import FuzzyMatcher, correct_transcript_segments
from .parse import parse_transcript_llm
from .normalize import normalize_recipe

console = Console()

def main():
    ap = argparse.ArgumentParser(description="vid2kg")
    ap.add_argument("--url", default=None)
    ap.add_argument("--input", default=None)
    ap.add_argument("--out", required=True)
    ap.add_argument("--engine", choices=["whisper","faster"], default="faster")
    ap.add_argument("--model", default="small")
    ap.add_argument("--skip-translation", action="store_true")
    ap.add_argument("--skip-fuzzy", action="store_true")
    ap.add_argument("--skip-llm", action="store_true")
    ap.add_argument("--skip-normalization", action="store_true")
    ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--force-translate", action="store_true")
    args = ap.parse_args()

    if not (args.url or args.input):
        ap.error("Provide either --url or --input")

    out_dir = pathlib.Path(args.out); out_dir.mkdir(parents=True, exist_ok=True)
    log_file = out_dir / "logs.txt"
    def log(msg):
        with open(log_file, "a", encoding="utf-8") as f: f.write(msg + "\n")
        if args.verbose: rprint(f"[dim]{msg}[/dim]")

    console.rule("[bold cyan]vid2kg: Video to Knowledge Graph")
    rprint(f"[green]Output directory:[/green] {out_dir}")

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        t1 = progress.add_task("[cyan]Step 1/5: Downloading audio...", total=None)
        audio = fetch_audio(args.url, args.input, out_dir); log(f"Audio: {audio}"); progress.update(t1, completed=True); rprint(f"[green]✓[/green] Audio: {audio.name}")
        t2 = progress.add_task("[cyan]Step 2/5: Transcribing...", total=None)
        transcript = transcribe(audio, engine=args.engine, model_size=args.model, out_dir=out_dir); progress.update(t2, completed=True); rprint("[green]✓[/green] Transcribed")
        (out_dir / "transcript_raw.json").write_text(json.dumps(transcript, ensure_ascii=False, indent=2), encoding="utf-8")
        if not args.skip_translation:
            t3 = progress.add_task("[cyan]Step 3/5: Translating...", total=None)
            transcript = translate_transcript(transcript, force=args.force_translate); progress.update(t3, completed=True); rprint("[green]✓[/green] Translation done")
        (out_dir / "transcript_translated.json").write_text(json.dumps(transcript, ensure_ascii=False, indent=2), encoding="utf-8")
        if not args.skip_fuzzy:
            t4 = progress.add_task("[cyan]Step 4/5: Correcting errors...", total=None)
            m = FuzzyMatcher(); transcript = correct_transcript_segments(transcript, m); progress.update(t4, completed=True); rprint("[green]✓[/green] Fuzzy fixes")
        (out_dir / "transcript_cleaned.json").write_text(json.dumps(transcript, ensure_ascii=False, indent=2), encoding="utf-8")
        t5 = progress.add_task("[cyan]Step 5/5: Extracting recipe...", total=None)
        if not args.skip_llm:
            try:
                parsed = parse_transcript_llm(transcript)
            except Exception:
                from .parse import parse_transcript as parse_regex
                parsed = parse_regex(transcript)
        else:
            from .parse import parse_transcript as parse_regex
            parsed = parse_regex(transcript)
        progress.update(t5, completed=True); rprint(f"[green]✓[/green] Extracted: {len(parsed.get('ingredients', []))} ingredients, {len(parsed.get('steps', []))} steps")
        (out_dir / "parsed_recipe.json").write_text(json.dumps(parsed, ensure_ascii=False, indent=2), encoding="utf-8")
        if not args.skip_normalization and parsed.get('ingredients'):
            parsed = normalize_recipe(parsed); (out_dir / "normalized_recipe.json").write_text(json.dumps(parsed, ensure_ascii=False, indent=2), encoding="utf-8")
            rprint("[green]✓[/green] Normalization complete")
    console.rule("[bold green]✓ Pipeline Complete")

if __name__ == "__main__":
    import sys; sys.exit(main())
