"""
Enhanced parsing module with LLM integration.
Includes both LLM-based extraction and regex fallback.
"""

import re
from typing import Dict, Any, List
from rich import print as rprint

# Try to import LLM client
try:
    from .utils.llm_client import LLMClient
    HAS_LLM = True
except Exception:
    HAS_LLM = False
    rprint("[yellow]Warning: LLM client not available, will use regex fallback[/yellow]")

# Regex patterns (fallback)
UNITS = r"(kg|g|gm|grams?|ml|l|litres?|tsp|tbsp|cup|cups|pinch|handful|katori|chamach|चम्मच|कप)"
NUM = r"(?:\d+(?:\.\d+)?)"
FRACTIONS = r"(?:\d+/\d+)"
QUANT = rf"(?:{NUM}|{FRACTIONS})\s*{UNITS}?"

ING_CUES = [
    r"ingredients?",
    r"सामग्री",
    r"उपकरण",
    r"ಪದಾರ್ಥ",
    r"ചേരുവകൾ",
    r"you will need",
    r"we need"
]

STEP_VERBS = [
    r"add", r"mix", r"heat", r"cook", r"fry", r"boil", r"saute", r"roast",
    r"भून", r"उबाल", r"धीमी", r"marinate", r"stir", r"chop", r"blend"
]


def parse_transcript_llm(transcript: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parse transcript using LLM for structured extraction.

    Args:
        transcript: Cleaned transcript dict

    Returns:
        dict: Structured recipe data
    """
    if not HAS_LLM:
        rprint("[yellow]LLM not available, falling back to regex parsing[/yellow]")
        return parse_transcript(transcript)

    try:
        rprint("[cyan]Using LLM for recipe extraction...[/cyan]")

        # Build full transcript text if missing
        text = transcript.get("text", "")
        if not text:
            segments = transcript.get("segments", [])
            text = " ".join(seg.get("text", "") for seg in segments)

        if not text or len(text.strip()) < 50:
            rprint("[yellow]Transcript too short for LLM extraction, using regex fallback[/yellow]")
            return parse_transcript(transcript)

        # Initialize LLM client
        client = LLMClient()

        # Call LLM for structured extraction
        recipe_data = client.extract_recipe_structured(text)

        # Ensure we have a dict
        if not isinstance(recipe_data, dict):
            rprint("[yellow]LLM returned non-dict result, falling back to regex[/yellow]")
            return parse_transcript(transcript)

        # Add metadata from transcript
        recipe_data.setdefault("title", "Unknown Recipe")
        recipe_data.setdefault("ingredients", [])
        recipe_data.setdefault("steps", [])

        recipe_data["language"] = transcript.get("language", "und")
        recipe_data["original_language"] = transcript.get("original_language", "Unknown")
        recipe_data["translated"] = transcript.get("translated", False)
        recipe_data["transcript_segments"] = len(transcript.get("segments", []))
        recipe_data["extraction_method"] = "llm"
        recipe_data["llm_extraction_success"] = True

        # Optional: LLM-based weight estimates for ingredients missing weights
        ingredients = recipe_data.get("ingredients", [])
        if isinstance(ingredients, list):
            for ing in ingredients:
                # Defensive: make sure it's a dict
                if not isinstance(ing, dict):
                    continue

                has_weight = ing.get("weight_grams") is not None
                has_qty = ing.get("quantity") is not None
                has_unit = ing.get("unit") is not None

                if (not has_weight) and has_qty and has_unit and ing.get("name"):
                    try:
                        est = client.estimate_ingredient_weight(
                            ing["name"], ing["quantity"], ing["unit"]
                        )
                        if est:
                            ing["weight_grams_llm_estimated"] = est
                    except Exception as e:
                        # Don't crash pipeline just because estimation failed
                        rprint(f"[yellow]Weight estimation failed for {ing.get('name')}: {e}[/yellow]")

        rprint("[green]✓ LLM extraction successful[/green]")
        return recipe_data

    except Exception as e:
        rprint(f"[red]LLM extraction failed: {e}[/red]")
        rprint("[yellow]Falling back to regex parsing...[/yellow]")
        return parse_transcript(transcript)


def parse_transcript(transcript: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parse transcript using regex patterns (fallback method).

    Args:
        transcript: Transcript dict

    Returns:
        dict: Basic parsed recipe data
    """
    rprint("[cyan]Using regex-based parsing (fallback)...[/cyan]")

    segments = transcript.get("segments", [])
    full_text = transcript.get("text", "")

    # If text is missing, build it from segments
    if not full_text and segments:
        full_text = " ".join(seg.get("text", "") for seg in segments)

    # Try to identify ingredient block
    ingredients: List[Dict[str, Any]] = []
    in_ingredient_block = False
    ing_text: List[str] = []

    cue_re = re.compile("|".join(ING_CUES), re.IGNORECASE)
    step_re = re.compile("|".join(STEP_VERBS), re.IGNORECASE)

    for seg in segments:
        text = seg.get("text", "").strip()
        if not text:
            continue

        # Check for ingredient cues
        if cue_re.search(text):
            in_ingredient_block = True
            continue

        # Check if we've moved to cooking steps
        if in_ingredient_block and step_re.search(text):
            in_ingredient_block = False

        if in_ingredient_block:
            ing_text.append(text)

    # Extract ingredients
    if ing_text:
        ingredients = _extract_ingredients("\n".join(ing_text))
    else:
        # Fallback: try to extract from full text
        ingredients = _extract_ingredients_simple(full_text)

    # Extract steps
    steps = _extract_steps(segments, step_re)

    # Build recipe structure
    recipe = {
        "title": _guess_title(full_text, segments),
        "language": transcript.get("language", "und"),
        "original_language": transcript.get("original_language", "Unknown"),
        "translated": transcript.get("translated", False),
        "ingredients": ingredients,
        "steps": steps,
        "cuisine": "Indian",  # default guess
        "servings": _guess_servings(full_text),
        "extraction_method": "regex",
        "llm_extraction_success": False,
    }

    return recipe


def _guess_title(text: str, segments: List[Dict[str, Any]]) -> str:
    """Guess recipe title from transcript."""
    title_patterns = [
        r"(?:today|aaj)\s+(?:we will make|we are making|bana rahe hain)\s+([^.!?\n]{5,50})",
        r"(?:recipe for|how to make)\s+([^.!?\n]{5,50})",
        r"^([A-Z][a-z]+(?:\s+[A-Z][a-z]+){0,3})",  # Title case at start
    ]

    for pattern in title_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            title = match.group(1).strip()
            if 5 < len(title) < 50:
                return title.title()

    # Use first segment if nothing found
    if segments:
        first_text = segments[0].get("text", "").strip()
        if first_text and len(first_text) < 80:
            return first_text.title()

    return "Unknown Recipe"


def _guess_servings(text: str) -> int:
    """Guess number of servings from text."""
    serving_patterns = [
        r"serves?\s+(\d+)",
        r"for\s+(\d+)\s+people",
        r"(\d+)\s+servings",
    ]

    for pattern in serving_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                return int(match.group(1))
            except ValueError:
                pass

    return 4  # default


def _extract_ingredients(block: str) -> List[Dict[str, Any]]:
    """Extract ingredients from text block."""
    ingredients: List[Dict[str, Any]] = []
    qre = re.compile(QUANT, re.IGNORECASE)

    lines = [l.strip(" -•\t*") for l in block.splitlines() if l.strip()]

    for line in lines:
        if len(line) < 3 or len(line) > 120:
            continue

        # Look for quantity pattern
        match = qre.search(line)

        qty = None
        unit = None
        name = line

        if match:
            # Extract quantity and unit
            qty_unit_str = match.group(0).strip()
            parts = qty_unit_str.split()

            if parts:
                qty_str = parts[0]
                try:
                    # Handle fractions
                    if "/" in qty_str:
                        num, denom = qty_str.split("/")
                        qty = float(num) / float(denom)
                    else:
                        qty = float(qty_str)
                except (ValueError, ZeroDivisionError):
                    qty = qty_str  # keep raw if not numeric

                if len(parts) > 1:
                    unit = parts[1]

            # Extract ingredient name (remove the quantity-unit part)
            name = (line[: match.start()] + line[match.end() :]).strip(", -•\t")

        if name:
            ingredients.append(
                {
                    "name": name,
                    "quantity": qty,
                    "unit": unit,
                    "raw_text": line,
                }
            )

    return ingredients


def _extract_ingredients_simple(text: str) -> List[Dict[str, Any]]:
    """Simple ingredient extraction from full text (last resort)."""
    ing_keywords = [
        "potato",
        "aloo",
        "onion",
        "pyaz",
        "tomato",
        "garlic",
        "ginger",
        "oil",
        "ghee",
        "salt",
        "chilli",
        "cumin",
        "jeera",
        "turmeric",
        "haldi",
        "rice",
        "chawal",
        "flour",
        "atta",
        "dal",
        "lentil",
    ]

    ingredients: List[Dict[str, Any]] = []
    text_lower = text.lower()

    for keyword in ing_keywords:
        if keyword in text_lower:
            ingredients.append(
                {
                    "name": keyword,
                    "quantity": None,
                    "unit": None,
                    "raw_text": f"(extracted: {keyword})",
                }
            )

    # Remove duplicates by name
    seen = set()
    unique: List[Dict[str, Any]] = []
    for ing in ingredients:
        if ing["name"] not in seen:
            seen.add(ing["name"])
            unique.append(ing)

    return unique


def _extract_steps(segments: List[Dict[str, Any]], step_re) -> List[Dict[str, Any]]:
    """Extract cooking steps from segments."""
    steps: List[Dict[str, Any]] = []
    step_num = 1

    for seg in segments:
        text = seg.get("text", "").strip()
        if not text:
            continue

        # Check if this segment contains a step verb
        if step_re.search(text) and len(text) > 10:
            steps.append(
                {
                    "order": step_num,
                    "instruction": text,
                    "timestamp_start": seg.get("start"),
                    "timestamp_end": seg.get("end"),
                }
            )
            step_num += 1

    return steps


if __name__ == "__main__":
    # Simple manual test (regex path)
    sample_transcript = {
        "language": "en",
        "text": """Today we will make delicious Aloo Paratha.

For ingredients you will need:
2 cups wheat flour
3 medium potatoes boiled
1 teaspoon cumin
Half teaspoon turmeric
Salt to taste
2 tablespoon oil
Ghee for cooking

First knead the flour with water.
Mash the boiled potatoes.
Mix cumin and turmeric with potatoes.
Roll out the dough.
Add filling and seal.
Cook on hot tawa with ghee.
Serve hot with curd.
""",
        "segments": [],
    }

    result = parse_transcript(sample_transcript)

    import json

    print("\n=== Parsed Recipe (Regex Test) ===")
    print(json.dumps(result, indent=2, ensure_ascii=False))

