from typing import Dict, Any
from rich import print as rprint
from googletrans import Translator
import langid
import re

translator = Translator()
LANG_NAMES = {'hi':'Hindi','ta':'Tamil','te':'Telugu','bn':'Bengali','ml':'Malayalam','en':'English','und':'Unknown'}

def detect_code_mixing(text: str) -> bool:
    return bool(re.search(r'[a-zA-Z]', text)) and bool(re.search(r'[\u0900-\u0D7F]', text))

def translate_text(text: str, src_lang: str = 'auto', dest_lang: str = 'en'):
    try:
        res = translator.translate(text, src=src_lang, dest=dest_lang)
        return {'translated': res.text, 'src': res.src}
    except Exception as e:
        rprint(f"[yellow]Translate failed: {e}[/yellow]")
        return {'translated': text, 'src': src_lang}

def translate_transcript(transcript: Dict[str, Any], force: bool = False) -> Dict[str, Any]:
    text = transcript.get('text', '')
    lang, _ = langid.classify(text) if text else ('und', 0.0)
    transcript['original_language'] = LANG_NAMES.get(lang, lang)
    if lang == 'en' and not force:
        transcript['translated'] = False
        return transcript
    new_segments = []
    for s in transcript.get('segments', []):
        res = translate_text(s.get('text', ''), src_lang=lang, dest_lang='en')
        s2 = s.copy(); s2['text_original'] = s.get('text', ''); s2['text'] = res['translated']; new_segments.append(s2)
    res_all = translate_text(text, src_lang=lang, dest_lang='en')
    transcript['text_original'] = text
    transcript['text'] = res_all['translated']
    transcript['segments'] = new_segments
    transcript['translated'] = True
    return transcript
