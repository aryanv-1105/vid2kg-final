import os
import json
import re
from typing import Any, Dict, Optional

from rich import print as rprint
from dotenv import load_dotenv
import google.generativeai as genai

# Load .env so GEMINI_API_KEY is picked up
load_dotenv()


class LLMClient:
    """
    Thin wrapper around Google Gemini for recipe extraction
    and ingredient weight estimation.
    """

    def __init__(self) -> None:
        api_key = (
            os.getenv("GEMINI_API_KEY")
            or os.getenv("GOOGLE_API_KEY")
        )

        if not api_key:
            raise RuntimeError(
                "No GEMINI_API_KEY / GOOGLE_API_KEY found in environment."
            )

        genai.configure(api_key=api_key)

        # Model name (from .env or default)
        env_model = os.getenv("LLM_MODEL", "gemini-2.5-flash")

        # In newer API, list_models() returns names like 'models/gemini-2.5-flash'
        # but GenerativeModel typically accepts 'gemini-2.5-flash' as well.
        # We'll just pass env_model directly.
        self.model_name = env_model
        self.model = genai.GenerativeModel(self.model_name)

        rprint(f"[cyan]LLMClient using model:[/cyan] {self.model_name}")

    # ------------------------------------------------------------------
    # Helper: extract JSON from model response
    # ------------------------------------------------------------------
    def _response_text(self, res: Any) -> str:
        """Get text from a GenerateContentResponse in a robust way."""
        # Preferred: res.text
        if hasattr(res, "text") and isinstance(res.text, str):
            return res.text

        # Fallback: assemble from candidates/parts
        try:
            parts = []
            for cand in getattr(res, "candidates", []):
                content = getattr(cand, "content", None)
                if not content:
                    continue
                for p in getattr(content, "parts", []):
                    if hasattr(p, "text") and isinstance(p.text, str):
                        parts.append(p.text)
            if parts:
                return "\n".join(parts)
        except Exception:
            pass

        # Last resort
        return str(res)

    def _extract_json(self, text: str) -> Dict[str, Any]:
        """
        Extract JSON object from a string.
        Handles ```json ... ``` blocks and raw JSON.
        """
        text = text.strip()

        # If wrapped in markdown code fences
        if "```" in text:
            # Try to find ```json ... ```
            match = re.search(r"```json(.*)```", text, re.DOTALL | re.IGNORECASE)
            if match:
                text = match.group(1).strip()
            else:
                # Any ``` ... ```
                match = re.search(r"```(.*)```", text, re.DOTALL)
                if match:
                    text = match.group(1).strip()

        # Now try to parse JSON directly
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            # Try to find the first {...} block
            match = re.search(r"\{.*\}", text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group(0))
                except json.JSONDecodeError:
                    pass

        raise ValueError("Could not parse JSON from LLM response")

    # ------------------------------------------------------------------
    # Public API: structured recipe extraction
    # ------------------------------------------------------------------
    def extract_recipe_structured(self, transcript_text: str) -> Dict[str, Any]:
        """
        Given a transcript, ask Gemini to output a strict JSON recipe structure.
        """
        prompt = f"""
You are an expert at reading Indian cooking transcripts and extracting structured recipes.

Read the following transcript of a cooking video and return a SINGLE JSON object
with this exact structure (no extra keys):

{{
  "title": "string",
  "cuisine": "string",
  "servings": 4,
  "prep_time_minutes": 0,
  "cooking_time_minutes": 0,
  "difficulty": "easy/medium/hard",
  "ingredients": [
    {{
      "name": "string (canonical English name if possible)",
      "quantity": 0,
      "unit": "string or null",
      "notes": "string (e.g. chopped, boiled) or empty string",
      "weight_grams": 0
    }}
  ],
  "steps": [
    {{
      "order": 1,
      "instruction": "string, short imperative sentence",
      "duration_minutes": 0
    }}
  ]
}}

IMPORTANT RULES:
- ALWAYS return valid JSON only. No comments, no explanations, no extra text.
- If you don't know an exact value, make your best reasonable guess.
- Use canonical ingredient names in English where possible (e.g. "potato" not "aloo").
- For `weight_grams`, use a reasonable approximation.
- Ensure the JSON parses correctly.

TRANSCRIPT:
\"\"\"{transcript_text}\"\"\"
        """.strip()

        res = self.model.generate_content(prompt)
        text = self._response_text(res)

        data = self._extract_json(text)

        # Basic sanity defaults
        data.setdefault("title", "Unknown Recipe")
        data.setdefault("cuisine", "Indian")
        data.setdefault("servings", 4)
        data.setdefault("prep_time_minutes", 0)
        data.setdefault("cooking_time_minutes", 0)
        data.setdefault("difficulty", "medium")
        data.setdefault("ingredients", [])
        data.setdefault("steps", [])

        return data

    # ------------------------------------------------------------------
    # Public API: estimate ingredient weight
    # ------------------------------------------------------------------
    def estimate_ingredient_weight(
        self,
        name: str,
        quantity: Any,
        unit: Optional[str],
    ) -> Optional[float]:
        """
        Ask the model to convert an ingredient quantity+unit to grams.
        Returns a float or None.
        """
        prompt = f"""
You convert cooking ingredient measurements to approximate weight in grams.

Ingredient: {name}
Quantity: {quantity}
Unit: {unit}

Respond with ONE number only: the approximate weight in grams.
No text, no units, no explanation.
        """.strip()

        try:
            res = self.model.generate_content(prompt)
            text = self._response_text(res).strip()

            # Extract first number
            match = re.search(r"\d+(\.\d+)?", text)
            if not match:
                return None
            return float(match.group(0))
        except Exception as e:
            rprint(f"[yellow]estimate_ingredient_weight failed for {name}: {e}[/yellow]")
            return None


if __name__ == "__main__":
    # Simple manual test
    client = LLMClient()
    sample = """
Hello everyone, today we will make Aloo Paratha.

For this recipe you will need:
- 2 cups wheat flour
- 3 medium aloo, boiled and mashed
- 1 teaspoon jeera
- 1/2 teaspoon haldi
- salt to taste
- ghee for cooking
"""
    out = client.extract_recipe_structured(sample)
    print(json.dumps(out, indent=2, ensure_ascii=False))









