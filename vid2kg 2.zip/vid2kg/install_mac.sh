#!/usr/bin/env bash
set -euo pipefail
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -r requirements.txt
cp -n .env.example .env || true
echo "Paste GEMINI_API_KEY into .env"
